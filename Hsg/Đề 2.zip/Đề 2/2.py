# Câu 2: Đoạn chương trình sau sẽ in ra kết quả bao nhiêu:
def f(x):
	return x**2, x**x**x
x,y=f(2)
print(x+y)

# đoạn chương trình trên sẽ ra kq là 20 ==> 4+16 --> x = 2**2 = 4, y = 2**2**2 = 16 