# Câu 1: Sau khi thực hiện chương trình sau thì kq là bao nhiêu?
kq=1
def calc(x):
	kq=4*x-1
	return kq
calc(7)

# kết quả của chương trình trên là 27 ==> (4*7)-1
